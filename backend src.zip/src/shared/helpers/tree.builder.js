/**
 * Permission tree builder.
 *
 * Converts raw MongoDB documents into the tree node shape
 * the frontend expects.
 *
 * Node contract (all levels):
 * {
 *   level:     1 | 2 | 3 | 4,
 *   label:     string,          ← localised display name
 *   module_en: string,          ← stable English key for API URLs
 *   data:      object,          ← level-specific fields
 *   children:  { data: node[] } | null,
 * }
 */

// ── i18n ──────────────────────────────────────────────────────────────────────

/**
 * Resolves a display label from an i18n map.
 * Falls back: requested lang → English → raw fallback string.
 */
function resolveLabel(i18n, lang, fallback = '') {
  if (!i18n)                     return fallback;
  if (typeof i18n === 'string')  return i18n || fallback;
  return i18n[lang] ?? i18n.en ?? fallback;
}

// ── Status ────────────────────────────────────────────────────────────────────

const STATUS_LABELS = {
  Active:   { en: 'Active',   ar: 'مفعل'     },
  Inactive: { en: 'Inactive', ar: 'غير مفعل' },
  Pending:  { en: 'Pending',  ar: 'معلق'     },
};

function resolveStatusLabel(status, lang) {
  return STATUS_LABELS[status]?.[lang] ?? status ?? 'Active';
}

// ── Node builders (level 4 → 1) ───────────────────────────────────────────────

function buildFieldNode(field, moduleEn, lang) {
  return {
    level:     4,
    label:     resolveLabel(field.i18n, lang, field.key),
    module_en: moduleEn,
    data: {
      field_key:          field.key,
      field_name:         resolveLabel(field.i18n, lang, field.key),
      field_access:       field.access ?? 'FULL',
      field_status:       field.status ?? 'Active',
      statusLabel:        resolveStatusLabel(field.status, lang),
      assignedRoleIds:    field.assignedRoleIds    ?? [],
      assignedRolesCount: field.assignedRolesCount ?? 0,
    },
    children: null,
  };
}

function buildPermissionNode(perm, moduleEn, roleId, lang) {
  const isChecked = roleId != null
    ? (perm.assignedRoleIds ?? []).includes(Number(roleId))
    : false;

  const fieldNodes = (perm.fieldPermissions ?? []).map(f =>
    buildFieldNode(f, moduleEn, lang)
  );

  // partial = not fully checked but at least one field is checked
  const partial_checked = !isChecked
    && fieldNodes.length > 0
    && fieldNodes.some(n => (n.data.assignedRoleIds ?? []).includes(Number(roleId)));

  return {
    level:     3,
    label:     resolveLabel(perm.i18n, lang, perm.key),
    module_en: moduleEn,
    data: {
      perm_key:            perm.key,
      perm_name:           resolveLabel(perm.i18n, lang, perm.key),
      perm_action:         perm.action ?? null,
      perm_status:         perm.status ?? 'Active',
      statusLabel:         resolveStatusLabel(perm.status, lang),
      perm_assigned_roles: perm.assignedRolesCount ?? 0,
      assignedRoleIds:     perm.assignedRoleIds    ?? [],
      checked:             isChecked,
      partial_checked,
    },
    children: { data: fieldNodes },
  };
}

function buildEntityNode(entity, moduleEn, roleId, lang) {
  const permNodes = (entity.permissions ?? []).map(p =>
    buildPermissionNode(p, moduleEn, roleId, lang)
  );

  const { checked, partial_checked } = aggregateCheckedState(permNodes);

  return {
    level:     2,
    label:     resolveLabel(entity.i18n, lang, entity.key),
    module_en: moduleEn,
    data: {
      entity_key:            entity.key,
      entity_name:           resolveLabel(entity.i18n, lang, entity.key),
      entity_category:       moduleEn,
      entity_status:         entity.status ?? 'Active',
      statusLabel:           resolveStatusLabel(entity.status, lang),
      entity_assigned_roles: entity.assignedRolesCount ?? 0,
      assignedRoleIds:       entity.assignedRoleIds    ?? [],
      checked,
      partial_checked,
    },
    children: { data: permNodes },
  };
}

function buildModuleNode(mod, roleId, lang) {
  // module_en: always English — used as the stable key in API URLs
  const moduleEn    = resolveLabel(mod.i18n, 'en', mod.name ?? '');
  const moduleLabel = resolveLabel(mod.i18n, lang,  mod.name ?? '');

  const entityNodes = (mod.entities ?? []).map(e =>
    buildEntityNode(e, moduleEn, roleId, lang)
  );

  return {
    level:     1,
    label:     moduleLabel,
    module_en: moduleEn,
    data: { module_name: moduleLabel },
    children: { data: entityNodes },
  };
}

// ── Aggregate checked state ────────────────────────────────────────────────────

/**
 * Derives parent checked/partial_checked from its children.
 *
 * Rules:
 *   all checked           → checked=true,  partial=false
 *   some checked/partial  → checked=false, partial=true
 *   none / no children    → checked=false, partial=false
 */
function aggregateCheckedState(childNodes) {
  if (!childNodes.length) return { checked: false, partial_checked: false };

  const total      = childNodes.length;
  const checkedCnt = childNodes.filter(n => n.data.checked).length;
  const partialCnt = childNodes.filter(n => n.data.partial_checked).length;

  if (checkedCnt === total)             return { checked: true,  partial_checked: false };
  if (checkedCnt > 0 || partialCnt > 0) return { checked: false, partial_checked: true  };
  return                                        { checked: false, partial_checked: false  };
}

module.exports = {
  buildModuleNode,
  buildEntityNode,
  buildPermissionNode,
  buildFieldNode,
  resolveLabel,
  resolveStatusLabel,
};